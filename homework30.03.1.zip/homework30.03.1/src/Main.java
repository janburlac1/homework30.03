import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Skoliko let vi v brake: ");
        int wednume = scr.nextInt();
        wednume = wednume +1;
        String message = switch (wednume){
            case 1 -> concat(Wedding.ODIN);
            case 2 -> concat(Wedding.DVA);
            case 3 -> concat(Wedding.TRI);
            case 4 -> concat(Wedding.CETIRE);
            case 5 -> concat(Wedding.PEATI);
            case 6 -> concat(Wedding.SESTI);
            case 7 -> concat(Wedding.SEMI);
            case 8 -> concat(Wedding.VOSEMI);
            case 9 -> concat(Wedding.DEVEATI);
            case 10 -> concat(Wedding.DESEASTI);
            case 11-> concat(Wedding.ODINATZATI);
            default -> "tacova znacenie net";

        };
        System.out.println(message);
    }
    public static String concat(Wedding nume){
        return nume.name() + "  " + nume.getDescription();

    }
}