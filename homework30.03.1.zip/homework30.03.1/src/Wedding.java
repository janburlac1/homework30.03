public enum Wedding{
    ODIN ("Ситцевая (марлевая) свадьба"),
    DVA("Бумажная свадьба"),
    TRI("Кожаная свадьба"),
    CETIRE("Льняная свадьба"),
    PEATI("Деревянная свадьба"),
    SESTI("Чугунная свадьба"),
    SEMI("Медная (Шерстяная) свадьба"),
    VOSEMI(" Жестяная свадьба"),
    DEVEATI(" Фаянсовая (ромашковая) свадьба"),
    DESEASTI("Оловянная свадьба"),
    ODINATZATI("Стальная свадьба");

    private final String description;

    public String getDescription() {
        return description;
    }
    Wedding(String description){
        this.description = description;
    }
}
